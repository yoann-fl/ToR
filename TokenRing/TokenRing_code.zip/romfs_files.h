#ifndef _ROMFS_FILES_H
#define _ROMFS_FILES_H

#include "resources/token.h"
#include "resources/token_w.h"

#endif // _ROMFS_FILES_H
