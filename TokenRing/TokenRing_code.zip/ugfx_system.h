#ifndef _UGFX_SYSTEM_H
#define _UGFX_SYSTEM_H

#include "gfx.h"
#include "resources_manager.h"

#endif // _UGFX_SYSTEM_H
