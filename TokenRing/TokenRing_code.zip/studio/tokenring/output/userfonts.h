#ifndef _USERFONTS_H
#define _USERFONTS_H

#include "resources/arial__14_arial14_aa.c"
#include "resources/arial_12_arial12_aa.c"

#endif // _USERFONTS_H
