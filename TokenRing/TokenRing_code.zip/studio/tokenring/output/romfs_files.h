#ifndef _ROMFS_FILES_H
#define _ROMFS_FILES_H

#include "resources/token_w.h"
#include "resources/token.h"

#endif // _ROMFS_FILES_H
